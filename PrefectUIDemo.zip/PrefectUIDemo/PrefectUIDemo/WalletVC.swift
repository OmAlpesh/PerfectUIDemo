//
//  WalletVC.swift
//  UIPerfect
//
//  Created by piyush sinroja on 25/01/17.
//  Copyright © 2017 Piyush. All rights reserved.
//

import UIKit
import PerfectUI

class WalletVC: UIViewController {

    @IBOutlet weak var consrt_Head_Height: NSLayoutConstraint!
    @IBOutlet weak var constr_segment_Height: NSLayoutConstraint!
    @IBOutlet weak var constr_btnHeight: NSLayoutConstraint!
    @IBOutlet weak var constr_txtHeight: NSLayoutConstraint!
    @IBOutlet weak var constr_txtFirstTop: NSLayoutConstraint!
    @IBOutlet weak var constr_btnTop: NSLayoutConstraint!
    @IBOutlet weak var constr_btnWidth: NSLayoutConstraint!
    
    //Array Of Constraints
    @IBOutlet var constr_Mix: [NSLayoutConstraint]!

    //UIButton Outlet
    @IBOutlet weak var btnRechargeNow: UIButton!
    
    //UILabel Outlets
    @IBOutlet weak var lblRupeeSymbol: UILabel!
    @IBOutlet weak var lblWalletAmount: UILabel!
    
    //UITextField outlets
    @IBOutlet weak var txtMobileNo: UITextField!
    @IBOutlet weak var txtamount: UITextField!
    @IBOutlet weak var txtOperator: UITextField!
    @IBOutlet weak var txtCircle: UITextField!
    
    // Array Of Constraints
    @IBOutlet var constr_txtLR: [NSLayoutConstraint]!
    @IBOutlet var constr_txtVertical: [NSLayoutConstraint]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // This Public Method is Used For Automatic set Constraints According To Device screen Size
        PixelsHelper.setConstraintAutomatic(constr: [consrt_Head_Height,constr_segment_Height,constr_txtHeight,constr_btnHeight,constr_txtFirstTop,constr_btnTop,constr_btnWidth] + constr_txtLR + constr_txtVertical + constr_Mix)
        
        // This Public Method is Used For Automatic set Font Size According To Device screen Size
        PixelsHelper.setFontForDevice(obj: [btnRechargeNow,txtMobileNo,txtamount,txtOperator,txtCircle,lblRupeeSymbol,lblWalletAmount])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
